use juniper::{EmptyMutation, FieldResult, GraphQLObject, RootNode, Variables};
use serde::Deserialize;
use std::sync::Arc;

// Context used in graphql resolver functions
struct Context {
    data: &'static str,
}

impl juniper::Context for Context {}

// Represents the public IP list. The backend JSON
// response is deserialized into this and then it is
// serialized into the response GraphQL object.
#[derive(Deserialize, GraphQLObject)]
/// Fastly Public IP Addresses
struct PublicIpList {
    /// IPv4 Addresses
    addresses: Vec<String>,
    /// IPv6 Addresses
    ipv6_addresses: Vec<String>,
}

struct Query;

#[juniper::object(
    Context = Context,
)]
impl Query {
    /// List Fastly Public IP Addresses
    fn public_ip_list(&self, context: &Context) -> FieldResult<PublicIpList> {
        let response = serde_json::from_str(context.data)?;
        let ips: PublicIpList = response;
        Ok(ips)
    }
}

fn main() {
    pretty_env_logger::init();
    // Instantiate the GraphQL schema
    let root_node = Arc::new(RootNode::new(Query, EmptyMutation::<Context>::new()));

    let ctx = Arc::new(Context {
        data: r#"{"addresses":["23.235.32.0/20","43.249.72.0/22","103.244.50.0/24","103.245.222.0/23","103.245.224.0/24","104.156.80.0/20","151.101.0.0/16","157.52.64.0/18","167.82.0.0/17","167.82.128.0/20","167.82.160.0/20","167.82.224.0/20","172.111.64.0/18","185.31.16.0/22","199.27.72.0/21","199.232.0.0/16"],"ipv6_addresses":["2a04:4e40::/32","2a04:4e42::/32"]}"#
    });

    let (res, _errors) = juniper::execute(
        "query query {
          publicIpList {
              addresses
              ipv6Addresses
            }
        }",
        None,
        &root_node,
        &Variables::new(),
        &ctx,
    )
    .unwrap();
    println!("{:?}", res)
}
